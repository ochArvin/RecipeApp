package com.recipeapp

import Flavor
import Recipe
import SwipeToDeleteCallback
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var etTitle: EditText
    private lateinit var etDescription: EditText
    private lateinit var btnAddSweet: Button
    private lateinit var btnAddSavory: Button
    private lateinit var recyclerView: RecyclerView

    private val recipes = mutableListOf<Recipe>()
    private lateinit var adapter: RecipeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupRecyclerView()
        setupClickListeners()
    }

    private fun initViews() {
        etTitle = findViewById(R.id.etTitle)
        etDescription = findViewById(R.id.etDescription)
        btnAddSweet = findViewById(R.id.btnAddSweet)
        btnAddSavory = findViewById(R.id.btnAddSavory)
        recyclerView = findViewById(R.id.recyclerView)
    }

    private fun setupRecyclerView() {
        adapter = RecipeAdapter(
            onRecipeClick = { recipe ->
                showRecipeDescription(recipe)
            },
            onRecipeSwipe = { recipe ->
                recipes.remove(recipe)
            }
        )

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Setup swipe to delete
        val itemTouchHelper = ItemTouchHelper(SwipeToDeleteCallback(adapter))
        itemTouchHelper.attachToRecyclerView(recyclerView)

        adapter.updateRecipes(recipes)
    }

    private fun setupClickListeners() {
        btnAddSweet.setOnClickListener {
            addRecipe(Flavor.SWEET)
        }

        btnAddSavory.setOnClickListener {
            addRecipe(Flavor.SAVORY)
        }
    }

    private fun addRecipe(flavor: Flavor) {
        val title = etTitle.text.toString().trim()
        val description = etDescription.text.toString().trim()

        if (title.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter both title and description", Toast.LENGTH_SHORT).show()
            return
        }

        val newRecipe = Recipe(
            title = title,
            description = description,
            flavor = flavor
        )

        recipes.add(newRecipe)
        adapter.updateRecipes(recipes)
        clearForm()

        Toast.makeText(this, "${flavor.name.lowercase().capitalize()} recipe added!", Toast.LENGTH_SHORT).show()
    }

    private fun clearForm() {
        etTitle.text.clear()
        etDescription.text.clear()
        etTitle.requestFocus()
    }

    private fun showRecipeDescription(recipe: Recipe) {
        AlertDialog.Builder(this)
            .setTitle(recipe.title)
            .setMessage(recipe.description)
            .setPositiveButton("OK", null)
            .show()
    }
}